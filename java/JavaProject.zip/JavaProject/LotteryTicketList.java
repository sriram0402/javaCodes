public class LotteryTicketList {
    
    String ticketName;
    int noOfTickets;
    String lotteryNumbers;
    double price;

    LotteryTicketList(String name,int totalTicket,String lotNumbers,double p){

        ticketName=name;
        noOfTickets=totalTicket;
        lotteryNumbers=lotNumbers;
        price=p;
    }
    
    
}
