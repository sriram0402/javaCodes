import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
// import GroceryItem.*;
public class GroceryMain {
    public static void main(String args[]){

        Scanner sc=new Scanner(System.in);
        ArrayList<GroceryItem> itemDetails = new ArrayList<GroceryItem>();
        while(true){
            GroceryItem addToCart=addToCart();
            itemDetails.add(addToCart);
            GroceryList weekly=new GroceryList();
            for(GroceryItem item:itemDetails){
                weekly.addItem(item);
            }
            weekly.printMe();
            weekly.totalCost();
            System.out.println("");
            System.out.println("Enter q to EXIT \n c to CONTINUE:");
            String userChoice = sc.next();
            if(userChoice.equals("q")){
                break;   
            }
        }
    }

    public static GroceryItem addToCart(){
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter the Fruit:");
        String fruit= sc.next();

        System.out.println("Enter the Price:");
        Double price= sc.nextDouble();

        System.out.println("Enter the Quantity:");
        int quantity= sc.nextInt();
        
        GroceryItem GroceryItem=new GroceryItem(fruit, price, quantity);

        return GroceryItem;
    }
        
}
    

